
public class Logic {
        public static void main(String[] args) {
// toán tử logic
        System.out.println((1 > 2) && (6 > 2)); //và
        System.out.println((2 < 3) || (3 < 2)); //hoặc
        System.out.println(!(1 == 3));
        
// toán tử quan hệ 
        System.out.println(1 == 2);
        System.out.println(1 != 2);
        System.out.println(1 > 2);
        System.out.println(1 < 2);
        System.out.println(1 >= 2);
        System.out.println(1 <= 2);
    }
}
