/*
- unit digit: đơn vị chữ số
- obtained: thu được
- Insert: chèn
- contains: có chứa
- combining: kết hợp
- calculated: tính toán
- range: phạm vi
- subtract: trừ
- An anagram: đảo chữ 
- chuỗi palindrome: xuôi ngược giống nhau
- phrase : cụm từ
- letters: các chữ cái
- digits: các chữ số
- valid: hợp lệ
- remove : xóa (có hỗ trợ trong java.list)
- multiply: nhân - divison: chia
- plus: cộng - minus: trừ
- Ascending: tăng dần
  Descending: giảm dần
  Positions: vị trí
- absolute : giá trị tuyệt đối (hàm Math.abs())
- Làm tròn lên - Math.ceil()
- Làm tròn xuống - Math.floor()
- Làm tròn - Math.round()
- Chia xong làm tròn đến số nguyên gần nhất (Math.floorDiv(x,y))
- Tìm số lớn nhất - Math.max() (vd: float maxFloat = Math.max(3.4f, 3.5f);), nhỏ nhất thay .min
- Lũy thừa - Math.pow()
- Overwrite: ghi đè
 */

class TuDien {
    public static void main(String args[]) {
        String abc= "abcde";
        System.err.println(abc.length());
    }
}

